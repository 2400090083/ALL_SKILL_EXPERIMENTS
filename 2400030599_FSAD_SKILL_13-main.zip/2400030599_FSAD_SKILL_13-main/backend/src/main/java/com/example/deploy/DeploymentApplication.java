
package com.example.deploy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeploymentApplication {
 public static void main(String[] args){
  SpringApplication.run(DeploymentApplication.class,args);
 }
}
